-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               12.0.2-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win64
-- HeidiSQL Version:             12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Dumping database structure for classroom
CREATE DATABASE IF NOT EXISTS `classroom` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_uca1400_ai_ci */;
USE `classroom`;

-- Dumping structure for table classroom.assignment_comments
CREATE TABLE IF NOT EXISTS `assignment_comments` (
  `comment_id` int(11) NOT NULL AUTO_INCREMENT,
  `assignment_id` int(11) NOT NULL,
  `user_id` varchar(50) NOT NULL,
  `comment_text` text NOT NULL,
  `created_datetime` datetime DEFAULT current_timestamp(),
  `updated_datetime` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted_flg` tinyint(4) DEFAULT 0,
  PRIMARY KEY (`comment_id`),
  KEY `assignment_id` (`assignment_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `assignment_comments_ibfk_1` FOREIGN KEY (`assignment_id`) REFERENCES `class_assignments` (`assignment_id`),
  CONSTRAINT `assignment_comments_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table classroom.assignment_comments: ~12 rows (approximately)
REPLACE INTO `assignment_comments` (`comment_id`, `assignment_id`, `user_id`, `comment_text`, `created_datetime`, `updated_datetime`, `deleted_flg`) VALUES
	(1, 12, '00001', 'ทักทาย', '2026-05-13 21:28:17', '2026-05-13 21:28:17', 0),
	(3, 12, '00001', 'test2', '2026-05-13 21:44:09', '2026-05-13 21:44:09', 0),
	(6, 12, '00001', 'Hello', '2026-05-13 21:44:29', '2026-05-14 21:52:38', 0),
	(7, 12, '69001', 'ดีมากครับ', '2026-05-14 21:58:31', '2026-05-14 21:58:31', 0),
	(8, 12, '69001', 'ดีมากครับ', '2026-05-14 21:58:31', '2026-05-14 21:58:31', 0),
	(9, 12, '69001', 'ดีมากครับ', '2026-05-14 21:58:31', '2026-05-14 21:58:31', 0),
	(10, 12, '69001', 'ดีครับ', '2026-05-14 21:58:43', '2026-05-14 21:58:43', 0),
	(11, 12, '69001', 'เก่ง', '2026-05-14 21:58:57', '2026-05-14 21:58:57', 0),
	(12, 12, '69001', 'เก่ง2', '2026-05-14 22:02:05', '2026-05-14 22:02:05', 0),
	(13, 12, '69001', 'เก่ง34556', '2026-05-14 22:11:38', '2026-06-14 18:42:19', 0),
	(16, 12, '00001', '***************@@@@@@@@@@@@@####################!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!fikgjfnmgifdgjdfiklgjfijoidgjkfgjfgjfopkodfkgdfgmdofgkdfopgdfkgopdfkgdfgdfgdfgfdgdfgsadadadad', '2026-06-14 18:43:14', '2026-06-14 19:23:35', 0),
	(17, 24, '00001', 'test0001', '2026-08-17 21:07:08', '2026-08-17 21:07:08', 0),
	(18, 28, '00001', 'test0001', '2026-08-17 21:09:53', '2026-08-17 21:09:53', 0);

-- Dumping structure for table classroom.assignment_files
CREATE TABLE IF NOT EXISTS `assignment_files` (
  `file_id` int(11) NOT NULL AUTO_INCREMENT,
  `assignment_id` int(11) NOT NULL,
  `file_name` varchar(255) NOT NULL DEFAULT '',
  `file_path` varchar(250) NOT NULL DEFAULT '',
  `file_size` bigint(20) NOT NULL DEFAULT 0,
  `deleted_flg` int(11) DEFAULT 0,
  `created_datetime` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`file_id`),
  KEY `work_id` (`assignment_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table classroom.assignment_files: ~10 rows (approximately)
REPLACE INTO `assignment_files` (`file_id`, `assignment_id`, `file_name`, `file_path`, `file_size`, `deleted_flg`, `created_datetime`) VALUES
	(1, 2, 'BIOMES.png', 'uploads\\assignments\\1770523402216-409201226.png', 46014, 0, '2026-02-08 04:03:22'),
	(2, 2, 'Screenshot 2023-02-01 014015.png', 'uploads\\assignments\\1770523402217-562070927.png', 704966, 0, '2026-02-08 04:03:22'),
	(3, 9, '512x512bb.jpg', 'uploads\\assignments\\1770536163576-394020121.jpg', 32332, 0, '2026-02-08 07:36:03'),
	(4, 11, 'z9GiDVW8p-lyYwDU5vKrYcJcTA4FBdHqPlZGUEMeAfc.png', 'uploads\\assignments\\1770536207442-715534751.png', 40823, 1, '2026-02-08 07:36:47'),
	(5, 11, 'Screenshot 2023-02-01 014015.png', 'uploads\\assignments\\1770536207442-387166344.png', 704966, 0, '2026-02-08 07:36:47'),
	(6, 11, '72bb167099543ac75578ea8a06bcb05e.gif', 'uploads\\assignments\\1770699062046-541955922.gif', 123309, 0, '2026-02-10 04:51:02'),
	(7, 12, 'Screenshot 2023-02-01 014015.png', 'uploads\\assignments\\1770722577605-795065914.png', 704966, 0, '2026-02-10 11:22:57'),
	(8, 13, 'z9GiDVW8p-lyYwDU5vKrYcJcTA4FBdHqPlZGUEMeAfc.png', 'uploads\\assignments\\1770724543770-343646461.png', 40823, 0, '2026-02-10 11:55:43'),
	(19, 25, 'ใบเบิก.pdf', 'uploads\\assignments\\1783321282703-475728900.pdf', 109176, 0, '2026-07-06 07:01:22'),
	(20, 25, 'เว็บไซต์สำหรับจัดการข้อมูลผลงานรายวิชาทางคอมพิวเตอร์ กรณีศึกษานิสิตสาขาวิศวกรรมคอมพิวเตอร์มหาวิทยาลัยพะเยา.docx', 'uploads\\assignments\\1783321282704-507542936.docx', 1708274, 0, '2026-07-06 07:01:22'),
	(21, 27, 'asus.jpg', 'uploads\\assignments\\1786904738708-973867152.jpg', 1768942, 0, '2026-08-16 18:25:38'),
	(22, 28, 'การบ้านจารน้อย(ปลายภาค).docx', 'uploads\\assignments\\1786975766788-245533577.docx', 1052653, 0, '2026-08-17 14:09:26');

-- Dumping structure for table classroom.classes
CREATE TABLE IF NOT EXISTS `classes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `class_id` varchar(20) NOT NULL DEFAULT '0',
  `class_name` varchar(100) NOT NULL DEFAULT '0',
  `class_describe` varchar(500) NOT NULL DEFAULT '0',
  `deleted_flg` int(11) NOT NULL,
  `deleted_by` varchar(10) DEFAULT NULL,
  `created_by` varchar(10) NOT NULL,
  `created_datetime` timestamp NOT NULL DEFAULT current_timestamp(),
  `created_user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`,`class_id`),
  KEY `class_id` (`class_id`),
  KEY `FK1_created_user_id` (`created_user_id`),
  CONSTRAINT `FK1_created_user_id` FOREIGN KEY (`created_user_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='เก็บรายวิชา';

-- Dumping data for table classroom.classes: ~22 rows (approximately)
REPLACE INTO `classes` (`id`, `class_id`, `class_name`, `class_describe`, `deleted_flg`, `deleted_by`, `created_by`, `created_datetime`, `created_user_id`) VALUES
	(1, 'web01', 'webtest', 'testtesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttest', 1, '00001', '00001', '2026-01-21 15:30:08', NULL),
	(2, 'test02', 'test02', 'test02test02test02test02test02test02test02', 1, '00001', '00001', '2026-01-24 15:05:43', NULL),
	(3, 'test03', 'test03', 'test03test03test03test03test03', 1, '00001', '00001', '2026-01-24 15:06:02', NULL),
	(4, 'test04', 'test04', 'test04test04test04test04test04test04', 1, '00001', '00001', '2026-01-24 15:06:10', NULL),
	(5, 'test05', 'test05', 'test05test05test05test05test05', 1, '00001', '00001', '2026-01-24 15:06:23', NULL),
	(6, 'test06', 'test06', 'test06test06test06test06test06', 1, '00001', '00001', '2026-01-24 15:06:30', NULL),
	(7, 'test07', 'test07', 'test07test07test07test07test07test07', 1, '00001', '00001', '2026-01-24 15:06:36', NULL),
	(8, 'test08', 'test08', 'test08test08test08test08test08', 1, '00001', '00001', '2026-01-24 15:06:43', NULL),
	(9, 'test09', 'test09', 'test09test09test09test09test09test09', 1, '00001', '00001', '2026-01-24 15:06:50', NULL),
	(10, 'test10', 'test10', 'test10test10test10test10test10test10', 1, '00001', '00001', '2026-01-24 15:06:55', NULL),
	(11, 'web11', 'Web Application test01', 'Web Application test02', 0, NULL, '00001', '2026-01-25 14:45:15', NULL),
	(12, 'LAB12', 'laboratory', 'test01111', 0, NULL, '00001', '2026-01-25 15:14:17', NULL),
	(13, 'OOP101', 'Object Oriented Programming', 'Object Oriented Programming', 0, NULL, '00001', '2026-02-07 14:00:31', NULL),
	(15, 'STEM12', 'STEM', 'STEM12', 0, NULL, '00001', '2026-02-08 07:47:07', NULL),
	(16, 'STAT13', 'Statistics', 'Statistics', 0, NULL, '00001', '2026-02-08 07:48:12', NULL),
	(17, 'JAVA001', 'Java Programming', 'Java Programming', 0, NULL, '00001', '2026-02-08 07:48:37', NULL),
	(18, 'NET152', 'Network Programming1', 'Network Programmimg', 0, NULL, '00001', '2026-02-08 07:49:12', NULL),
	(19, 'ENG101', 'English for Business', 'English for Business', 0, NULL, '00001', '2026-02-08 07:50:57', NULL),
	(20, 'BAS015', 'Basic tools skill', 'Basic tools skill', 0, NULL, '00001', '2026-02-08 07:51:19', NULL),
	(21, 'STAT14', 'Statistics 2', 'Statistics 2', 0, NULL, '00001', '2026-02-08 07:51:40', NULL),
	(24, 'TECH0185', 'TECH', 'test1', 0, NULL, '69001', '2026-02-16 13:44:11', NULL),
	(25, 'GAME01', 'Gaming', 'GamingGamingGamingGamingGaming0', 0, NULL, '00001', '2026-02-20 15:53:48', NULL);

-- Dumping structure for table classroom.class_assignments
CREATE TABLE IF NOT EXISTS `class_assignments` (
  `assignment_id` int(11) NOT NULL AUTO_INCREMENT,
  `class_id` varchar(10) NOT NULL,
  `assignment_type` varchar(20) NOT NULL,
  `assignment_name` varchar(60) DEFAULT NULL,
  `assignment_detail` varchar(500) DEFAULT NULL,
  `assignment_link` varchar(300) DEFAULT NULL,
  `view_cnt` int(11) DEFAULT 0,
  `deleted_flg` int(11) DEFAULT NULL,
  `created_by` varchar(10) DEFAULT NULL,
  `deleted_by` varchar(10) DEFAULT NULL,
  `created_datetime` timestamp NULL DEFAULT current_timestamp(),
  `updated_datetime` datetime DEFAULT NULL,
  PRIMARY KEY (`assignment_id`) USING BTREE,
  KEY `class_id` (`class_id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table classroom.class_assignments: ~20 rows (approximately)
REPLACE INTO `class_assignments` (`assignment_id`, `class_id`, `assignment_type`, `assignment_name`, `assignment_detail`, `assignment_link`, `view_cnt`, `deleted_flg`, `created_by`, `deleted_by`, `created_datetime`, `updated_datetime`) VALUES
	(1, 'web11', 'Web', 'Assignment01', 'test01', '', 0, 1, '00001', NULL, '2026-02-08 03:45:47', NULL),
	(2, 'LAB12', 'Other', 'Assignment01', 'test0001', NULL, 151, 0, '00001', NULL, '2026-02-08 04:03:22', NULL),
	(3, 'LAB12', 'Web', 'Project : Online course Platform', 'test02', 'https://www.youtube.com/', 544, 0, '00001', NULL, '2026-02-08 06:06:39', NULL),
	(4, 'LAB12', 'Document', 'Assignment 03', 'Assignment 03', NULL, 52346, 0, '00001', NULL, '2026-02-08 07:34:27', NULL),
	(5, 'LAB12', 'IOT', 'Assignment 004', 'Assignment 004 test', '', 5311, 0, '00001', NULL, '2026-02-08 07:34:43', '2026-02-10 11:05:12'),
	(6, 'LAB12', 'Web Application', 'Assignment 05', 'Assignment 05', NULL, 10, 1, '00001', '00001', '2026-02-08 07:35:30', '2026-02-10 18:15:48'),
	(7, 'LAB12', 'Application', 'Assignment 06', 'Assignment 06', NULL, 1, 0, '00001', NULL, '2026-02-08 07:35:39', NULL),
	(8, 'LAB12', 'IOT', 'Assignment 07', 'Assignment 07', NULL, 1, 0, '00001', NULL, '2026-02-08 07:35:49', NULL),
	(9, 'LAB12', 'Other', 'Assignment 08', 'Assignment 08', NULL, 1, 0, '00001', NULL, '2026-02-08 07:36:03', NULL),
	(10, 'LAB12', 'Web', 'Assignment 09', 'Assignment 09', 'https://www.youtube.com/', 1, 0, '00001', NULL, '2026-02-08 07:36:25', NULL),
	(11, 'LAB12', 'Document', 'Assignment 010', 'Assignment 00010', NULL, 1, 0, '00001', NULL, '2026-02-08 07:36:47', '2026-02-10 11:51:02'),
	(12, 'web11', 'IOT', 'webbbbbbb', 'webbbbbbbbbbbbbbbbbbbb', NULL, 132, 0, '69004', NULL, '2026-02-10 11:22:57', NULL),
	(13, 'ENG101', 'Web', 'English test', 'English test', NULL, 1152, 0, '00001', NULL, '2026-02-10 11:55:43', NULL),
	(22, 'GAME01', 'Web', 'test', 'none', 'https://github.com/Teeraphat120945/PJ-Hub', 5, 1, '00001', '00001', '2026-07-06 06:30:16', '2026-08-17 21:09:31'),
	(23, 'GAME01', 'IOT', 'Test001 for function', 'Test001 for function', NULL, 7, 0, '00001', NULL, '2026-07-06 06:33:19', NULL),
	(24, 'GAME01', 'Web', 'Test002 for function', 'Test002 for function', NULL, 23, 0, '00001', NULL, '2026-07-06 06:44:47', '2026-07-06 13:56:33'),
	(25, 'GAME01', 'Web', 'Test003 for function save files', 'Test003 for function save files', NULL, 8, 0, '00001', NULL, '2026-07-06 07:01:22', NULL),
	(26, 'web11', 'Web', '55', '', NULL, 2, 0, '69002', NULL, '2026-08-16 18:25:01', NULL),
	(27, 'web11', 'Web', 'test01', 'none', NULL, 2, 0, '69002', NULL, '2026-08-16 18:25:38', NULL),
	(28, 'GAME01', 'Document', 'test0001', 'test0001', 'https://github.com/Teeraphat120945/PJ-Hub', 6, 0, '00001', NULL, '2026-08-17 14:09:26', NULL);

-- Dumping structure for table classroom.class_users
CREATE TABLE IF NOT EXISTS `class_users` (
  `class_id` varchar(10) NOT NULL DEFAULT '',
  `user_id` varchar(10) NOT NULL DEFAULT '',
  `view_flg` int(11) DEFAULT NULL,
  `deleted_flg` int(11) DEFAULT NULL,
  `deleted_by` varchar(10) DEFAULT NULL,
  `created_datetime` datetime DEFAULT current_timestamp(),
  `updated_datetime` datetime DEFAULT NULL,
  PRIMARY KEY (`class_id`,`user_id`),
  KEY `class_id` (`class_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='permission';

-- Dumping data for table classroom.class_users: ~30 rows (approximately)
REPLACE INTO `class_users` (`class_id`, `user_id`, `view_flg`, `deleted_flg`, `deleted_by`, `created_datetime`, `updated_datetime`) VALUES
	('BAS015', '00001', 0, 0, NULL, '2026-02-08 14:51:19', NULL),
	('ENG101', '00001', 0, 0, NULL, '2026-02-08 14:50:57', NULL),
	('GAME01', '00001', 0, 0, NULL, '2026-02-20 22:53:48', NULL),
	('GAME01', '69001', 0, 0, NULL, '2026-08-17 21:10:54', NULL),
	('GAME01', '69002', 0, 0, NULL, '2026-08-17 21:11:11', NULL),
	('GAME01', '69003', 0, 0, NULL, '2026-08-17 21:10:58', NULL),
	('JAVA001', '00001', 0, 0, NULL, '2026-02-08 14:48:37', NULL),
	('LAB12', '00001', 0, 0, NULL, '2026-01-25 22:14:17', '2026-02-01 23:59:58'),
	('LAB12', '69004', 0, 0, NULL, '2026-02-02 00:02:52', '2026-02-02 00:02:52'),
	('LAB12', '69007', 1, 1, '00001', '2026-02-10 18:25:41', NULL),
	('NET152', '00001', 0, 0, NULL, '2026-02-08 14:49:12', NULL),
	('OOP101', '00001', 0, 0, NULL, '2026-02-07 21:00:31', NULL),
	('STAT13', '00001', 0, 0, NULL, '2026-02-08 14:48:12', NULL),
	('STAT14', '00001', 0, 0, NULL, '2026-02-08 14:51:40', NULL),
	('STAT14', '69001', 0, 0, NULL, '2026-02-08 15:21:52', NULL),
	('STEM12', '00001', 0, 0, NULL, '2026-02-08 14:47:07', NULL),
	('TECH0185', '00001', 0, 0, NULL, '2026-02-16 20:44:11', NULL),
	('TECH0185', '69001', 0, 0, NULL, '2026-02-16 20:44:11', NULL),
	('TECH0185', '69003', 0, 0, NULL, '2026-02-20 22:48:52', NULL),
	('TECH0185', '69005', 0, 0, NULL, '2026-02-20 22:49:01', NULL),
	('TECH0185', '69014', 0, 0, NULL, '2026-07-23 01:21:08', NULL),
	('web11', '00001', 0, 0, NULL, '2026-01-25 21:45:15', '2026-02-01 23:59:58'),
	('web11', '69001', 0, 0, NULL, '2026-02-01 23:59:33', '2026-02-01 23:59:58'),
	('web11', '69002', 0, 0, NULL, '2026-02-01 23:59:33', '2026-02-01 23:59:58'),
	('web11', '69004', 0, 0, NULL, '2026-02-01 18:19:03', '2026-02-01 23:59:58'),
	('web11', '69005', 0, 0, NULL, '2026-02-01 23:59:34', '2026-02-01 23:59:58'),
	('web11', '69006', 0, 0, NULL, '2026-02-01 23:59:34', '2026-02-01 23:59:58'),
	('web11', '69007', 0, 0, NULL, '2026-02-01 23:59:34', '2026-02-01 23:59:58'),
	('web11', '69008', 0, 0, NULL, '2026-02-01 23:59:35', '2026-02-01 23:59:58'),
	('web11', '69009', 0, 0, NULL, '2026-02-02 00:15:58', NULL);

-- Dumping structure for table classroom.ref_number
CREATE TABLE IF NOT EXISTS `ref_number` (
  `name` varchar(50) NOT NULL DEFAULT '',
  `prefix` varchar(50) DEFAULT NULL,
  `current_value` int(11) DEFAULT 1,
  `pad_length` int(11) DEFAULT 2,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table classroom.ref_number: ~0 rows (approximately)
REPLACE INTO `ref_number` (`name`, `prefix`, `current_value`, `pad_length`) VALUES
	('user', '69', 16, 2);

-- Dumping structure for table classroom.ref_role
CREATE TABLE IF NOT EXISTS `ref_role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) NOT NULL DEFAULT 0,
  `role_name` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`,`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table classroom.ref_role: ~4 rows (approximately)
REPLACE INTO `ref_role` (`id`, `role_id`, `role_name`) VALUES
	(1, 0, 'ผู้ดูแลระบบ'),
	(2, 1, 'อาจารย์'),
	(3, 2, 'นักเรียน'),
	(4, 3, 'ผู้ใช้ทั่วไป');

-- Dumping structure for table classroom.users
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(10) NOT NULL DEFAULT '0',
  `user_name` varchar(50) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `user_password` varchar(255) DEFAULT NULL,
  `google_id` varchar(255) DEFAULT NULL,
  `microsoft_id` varchar(255) DEFAULT NULL,
  `avatar_url` varchar(500) DEFAULT NULL,
  `role_flg` int(11) DEFAULT NULL,
  `deleted_flg` int(11) NOT NULL,
  `last_login` datetime DEFAULT NULL,
  `created_datetime` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_datetime` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`,`user_id`) USING BTREE,
  UNIQUE KEY `user_name` (`user_name`),
  UNIQUE KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table classroom.users: ~17 rows (approximately)
REPLACE INTO `users` (`id`, `user_id`, `user_name`, `email`, `user_password`, `google_id`, `microsoft_id`, `avatar_url`, `role_flg`, `deleted_flg`, `last_login`, `created_datetime`, `updated_datetime`) VALUES
	(1, '00001', 'admin', NULL, '$2b$10$clqi0BzvKooB5BtSCDTrseEuJXchlOjSbKS.Ardv80Ns3SVG1Zv8.', NULL, NULL, NULL, 0, 0, '2026-08-18 18:04:59', '2026-01-18 14:11:54', NULL),
	(2, '69001', 'teacher', NULL, '$2b$10$dO0JpY//XFfl2EzW/6GOhu9rsh7Re8ikt1/pGGfR337ED9ml3KWwS', NULL, NULL, NULL, 1, 0, '2026-08-17 21:21:07', '2026-01-18 14:22:06', NULL),
	(3, '69002', 'student01', NULL, '$2b$10$dO0JpY//XFfl2EzW/6GOhu9rsh7Re8ikt1/pGGfR337ED9ml3KWwS', NULL, NULL, NULL, 2, 0, '2026-08-17 01:24:37', '2026-01-18 14:22:53', NULL),
	(4, '69003', 'other', NULL, '$2b$10$dO0JpY//XFfl2EzW/6GOhu9rsh7Re8ikt1/pGGfR337ED9ml3KWwS', NULL, NULL, NULL, 3, 0, '2026-08-18 18:05:28', '2026-01-18 14:24:04', NULL),
	(5, '69004', 'student02', NULL, '$2b$10$KeRjpR.La3MO0N90gM.K6uo4wwgO7YKDqcWHWhUA4JdH3Z3Z6ElBm', NULL, NULL, NULL, 2, 0, '2026-02-10 18:33:58', '2026-01-24 14:17:00', NULL),
	(6, '69005', 'student03', NULL, '$2b$10$CteeuAXh9GPdOR0xvoCScuhWPvP6qHZdtlQyIEwL53UYJjMqx3isq', NULL, NULL, NULL, 2, 0, NULL, '2026-01-24 14:17:10', NULL),
	(7, '69006', 'student04', NULL, '$2b$10$MW2APc1UmAM4fJT8AxBYy.o8cX.4/Js7v270T33NGqrbqumkAGKXC', NULL, NULL, NULL, 2, 0, NULL, '2026-01-24 14:18:05', NULL),
	(8, '69007', 'student05', NULL, '$2b$10$WPd1Nsa1ihkta2ioA926Lu0D/TE5Qm2hXpSjmlVnFvqUY0ZAQQDyq', NULL, NULL, NULL, 2, 0, NULL, '2026-01-24 14:18:59', NULL),
	(9, '69008', 'student06', NULL, '$2b$10$3ItPKQgTI0l7RhB9LkHOSOinRxzey3BYiK4T64SHs1qs06kDcPgo2', NULL, NULL, NULL, 2, 0, NULL, '2026-01-24 14:19:11', NULL),
	(10, '69009', 'student07', NULL, '$2b$10$izwD5ZrfbMrnbUYid0NjVuW81UjsI5IOdGt1O2xwvmP2U.7XClZym', NULL, NULL, NULL, 2, 0, NULL, '2026-01-24 14:19:21', NULL),
	(11, '69010', 'student08', NULL, '$2b$10$2I.GkPrcunrJBqoTbIuFzu0B2f2YiQ/7NyL/zgKmxP82zDMCdILDS', NULL, NULL, NULL, 2, 0, NULL, '2026-01-24 14:19:42', NULL),
	(12, '69011', 'student09', NULL, '$2b$10$nI3GTBNMgy3Dvg11udUMne5hV0eNmSD75gnLVVGCM8UyBV8/kmYN.', NULL, NULL, NULL, 2, 0, NULL, '2026-01-24 14:19:55', NULL),
	(13, '69012', 'student10', NULL, '$2b$10$mk30Z22qmTUicG62MdhHQOnIkICEio8R0/6e1ChxT9byW2qXTFFfy', NULL, NULL, NULL, 2, 0, NULL, '2026-01-24 14:20:08', NULL),
	(14, '69013', 'student11', NULL, '$2b$10$dO0JpY//XFfl2EzW/6GOhu9rsh7Re8ikt1/pGGfR337ED9ml3KWwS', NULL, NULL, NULL, 2, 0, '2026-07-06 17:01:55', '2026-02-01 11:31:10', NULL),
	(15, '69014', 'teacher01', NULL, '$2b$10$dO0JpY//XFfl2EzW/6GOhu9rsh7Re8ikt1/pGGfR337ED9ml3KWwS', NULL, NULL, NULL, 1, 0, '2026-07-10 16:37:37', '2026-02-10 11:11:51', NULL),
	(16, '69015', 'test001', NULL, '$2b$10$dO0JpY//XFfl2EzW/6GOhu9rsh7Re8ikt1/pGGfR337ED9ml3KWwS', NULL, NULL, NULL, 3, 0, '2026-07-06 16:47:28', '2026-07-06 09:25:06', NULL),
	(17, '69016', 'none', NULL, '$2b$10$0.xubJtnUH2uX3.ErGP./OedPfpp7SFK2g1ia5oseh8xZNUjkjFS2', NULL, NULL, NULL, 3, 0, '2026-07-06 16:59:55', '2026-07-06 09:59:48', NULL);

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
