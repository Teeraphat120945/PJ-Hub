-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               12.0.2-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win64
-- HeidiSQL Version:             12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Dumping database structure for classroom
CREATE DATABASE IF NOT EXISTS `classroom` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_uca1400_ai_ci */;
USE `classroom`;

-- Dumping structure for table classroom.assignment_files
CREATE TABLE IF NOT EXISTS `assignment_files` (
  `file_id` int(11) NOT NULL AUTO_INCREMENT,
  `assignment_id` int(11) NOT NULL,
  `file_name` varchar(250) NOT NULL DEFAULT '',
  `file_path` varchar(250) NOT NULL DEFAULT '',
  `file_size` bigint(20) NOT NULL DEFAULT 0,
  `deleted_flg` int(11) DEFAULT 0,
  `created_datetime` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`file_id`),
  KEY `work_id` (`assignment_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table classroom.assignment_files: ~2 rows (approximately)
REPLACE INTO `assignment_files` (`file_id`, `assignment_id`, `file_name`, `file_path`, `file_size`, `deleted_flg`, `created_datetime`) VALUES
	(1, 1, '519418675_2160688764394094_4682523181030450484_n.jpg', 'uploads\\assignments\\1771245482157-924479761.jpg', 37546, 0, '2026-02-16 12:38:02'),
	(2, 1, 'Screenshot 2024-10-03 160139.png', 'uploads\\assignments\\1771246020510-203637325.png', 131987, 0, '2026-02-16 12:47:00');

-- Dumping structure for table classroom.classes
CREATE TABLE IF NOT EXISTS `classes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `class_id` varchar(20) NOT NULL DEFAULT '0',
  `class_name` varchar(100) NOT NULL DEFAULT '0',
  `class_describe` varchar(200) NOT NULL DEFAULT '0',
  `deleted_flg` int(11) NOT NULL,
  `deleted_by` varchar(10) DEFAULT NULL,
  `created_by` varchar(10) NOT NULL,
  `created_datetime` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`,`class_id`),
  KEY `class_id` (`class_id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='เก็บรายวิชา';

-- Dumping data for table classroom.classes: ~2 rows (approximately)
REPLACE INTO `classes` (`id`, `class_id`, `class_name`, `class_describe`, `deleted_flg`, `deleted_by`, `created_by`, `created_datetime`) VALUES
	(1, 'WEB01', 'Web programming', 'test Web programming', 0, NULL, '00001', '2026-02-16 12:35:19'),
	(14, 'CPE101', 'หลักการเเก้ไขปัญหา', 'C Programming', 0, NULL, '00001', '2026-02-16 13:29:52'),
	(19, 'CPE0021', 'หลักการเเก้ไขปัญหา', '', 0, NULL, '69002', '2026-02-16 13:48:38');

-- Dumping structure for table classroom.class_assignments
CREATE TABLE IF NOT EXISTS `class_assignments` (
  `assignment_id` int(11) NOT NULL AUTO_INCREMENT,
  `class_id` varchar(10) NOT NULL,
  `assignment_type` varchar(20) NOT NULL,
  `assignment_name` varchar(60) DEFAULT NULL,
  `assignment_detail` varchar(300) DEFAULT NULL,
  `assignment_link` varchar(300) DEFAULT NULL,
  `deleted_flg` int(11) DEFAULT NULL,
  `created_by` varchar(10) DEFAULT NULL,
  `deleted_by` varchar(10) DEFAULT NULL,
  `created_datetime` timestamp NULL DEFAULT current_timestamp(),
  `updated_datetime` datetime DEFAULT NULL,
  PRIMARY KEY (`assignment_id`) USING BTREE,
  KEY `class_id` (`class_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table classroom.class_assignments: ~2 rows (approximately)
REPLACE INTO `class_assignments` (`assignment_id`, `class_id`, `assignment_type`, `assignment_name`, `assignment_detail`, `assignment_link`, `deleted_flg`, `created_by`, `deleted_by`, `created_datetime`, `updated_datetime`) VALUES
	(1, 'WEB01', 'Web', 'Assignemnt 01', 'test 01111', NULL, 0, '00001', NULL, '2026-02-16 12:38:02', '2026-02-16 19:47:00'),
	(2, 'WEB01', 'Application', 'Assignement 02', 'test Assignment02', 'https://www.youtube.com/', 0, '00001', NULL, '2026-02-16 12:38:36', NULL);

-- Dumping structure for table classroom.class_users
CREATE TABLE IF NOT EXISTS `class_users` (
  `class_id` varchar(10) NOT NULL DEFAULT '',
  `user_id` varchar(10) NOT NULL DEFAULT '',
  `role_flg` int(11) DEFAULT NULL,
  `view_flg` int(11) DEFAULT NULL,
  `deleted_flg` int(11) DEFAULT NULL,
  `deleted_by` varchar(10) DEFAULT NULL,
  `created_datetime` datetime DEFAULT current_timestamp(),
  `updated_datetime` datetime DEFAULT NULL,
  PRIMARY KEY (`class_id`,`user_id`),
  KEY `class_id` (`class_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='permission';

-- Dumping data for table classroom.class_users: ~6 rows (approximately)
REPLACE INTO `class_users` (`class_id`, `user_id`, `role_flg`, `view_flg`, `deleted_flg`, `deleted_by`, `created_datetime`, `updated_datetime`) VALUES
	('CPE0021', '00001', 0, 0, 0, NULL, '2026-02-16 20:48:38', NULL),
	('CPE0021', '69002', 1, 0, 0, NULL, '2026-02-16 20:48:38', NULL),
	('CPE0021', '69003', 2, 0, 0, NULL, '2026-02-16 20:56:33', NULL),
	('CPE101', '00001', 0, 0, 0, NULL, '2026-02-16 20:29:52', NULL),
	('CPE101', '69003', 2, 0, 0, NULL, '2026-02-16 20:56:38', NULL),
	('WEB01', '00001', 0, 0, 0, NULL, '2026-02-16 19:35:19', NULL),
	('WEB01', '69003', 2, 0, 0, NULL, '2026-02-16 20:56:08', NULL);

-- Dumping structure for table classroom.ref_number
CREATE TABLE IF NOT EXISTS `ref_number` (
  `name` varchar(50) NOT NULL DEFAULT '',
  `prefix` varchar(50) DEFAULT NULL,
  `current_value` int(11) DEFAULT 1,
  `pad_length` int(11) DEFAULT 2,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table classroom.ref_number: ~0 rows (approximately)
REPLACE INTO `ref_number` (`name`, `prefix`, `current_value`, `pad_length`) VALUES
	('user', '69', 4, 2);

-- Dumping structure for table classroom.users
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(10) NOT NULL DEFAULT '0',
  `user_name` varchar(50) NOT NULL,
  `user_password` varchar(255) NOT NULL,
  `role_flg` int(11) DEFAULT NULL,
  `deleted_flg` int(11) NOT NULL,
  `last_login` datetime DEFAULT NULL,
  `created_datetime` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_datetime` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`,`user_id`) USING BTREE,
  UNIQUE KEY `user_name` (`user_name`),
  UNIQUE KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table classroom.users: ~4 rows (approximately)
REPLACE INTO `users` (`id`, `user_id`, `user_name`, `user_password`, `role_flg`, `deleted_flg`, `last_login`, `created_datetime`, `updated_datetime`) VALUES
	(1, '00001', 'admin', '$2b$10$clqi0BzvKooB5BtSCDTrseEuJXchlOjSbKS.Ardv80Ns3SVG1Zv8.', 0, 0, '2026-02-16 20:55:42', '2026-01-18 14:11:54', NULL),
	(16, '69002', 'teacher01', '$2b$10$fCSDdVdCk.64/3Y0e06YYucl8G.pfJ6mcRkI2qeB5fcxPwY46CY9.', 1, 0, '2026-02-16 20:50:06', '2026-02-15 23:35:35', NULL),
	(17, '69003', 'student01', '$2b$10$V7MVZovablSci2MZcWfTiuGBO8A9anmI61VvhTQxZoj7dgptnvVPO', 2, 0, '2026-02-16 20:56:59', '2026-02-15 23:44:19', NULL),
	(18, '69004', 'teacher02', '$2b$10$QuhOuFDkzbU1N4A/Zw743uRI485pEcTnms8K5bXiUGn7.kaVNa7le', 1, 0, NULL, '2026-02-16 13:21:03', NULL);

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
