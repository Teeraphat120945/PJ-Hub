-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               12.0.2-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win64
-- HeidiSQL Version:             12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Dumping database structure for classroom
CREATE DATABASE IF NOT EXISTS `classroom` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_uca1400_ai_ci */;
USE `classroom`;

-- Dumping structure for table classroom.assignment_comments
CREATE TABLE IF NOT EXISTS `assignment_comments` (
  `comment_id` int(11) NOT NULL AUTO_INCREMENT,
  `assignment_id` int(11) NOT NULL,
  `user_id` varchar(50) NOT NULL,
  `comment_text` text NOT NULL,
  `created_datetime` datetime DEFAULT current_timestamp(),
  `updated_datetime` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted_flg` tinyint(4) DEFAULT 0,
  PRIMARY KEY (`comment_id`),
  KEY `assignment_id` (`assignment_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `assignment_comments_ibfk_1` FOREIGN KEY (`assignment_id`) REFERENCES `class_assignments` (`assignment_id`),
  CONSTRAINT `assignment_comments_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table classroom.assignment_comments: ~2 rows (approximately)
INSERT INTO `assignment_comments` (`comment_id`, `assignment_id`, `user_id`, `comment_text`, `created_datetime`, `updated_datetime`, `deleted_flg`) VALUES
	(16, 26, '69018', 'Goog job', '2026-10-10 16:27:30', '2026-10-10 16:27:30', 0),
	(17, 26, '00001', 'Nice try', '2026-10-10 16:29:03', '2026-10-10 16:29:03', 0);

-- Dumping structure for table classroom.assignment_files
CREATE TABLE IF NOT EXISTS `assignment_files` (
  `file_id` int(11) NOT NULL AUTO_INCREMENT,
  `assignment_id` int(11) NOT NULL,
  `file_name` varchar(250) NOT NULL DEFAULT '',
  `file_path` varchar(250) NOT NULL DEFAULT '',
  `file_size` bigint(20) NOT NULL DEFAULT 0,
  `deleted_flg` int(11) DEFAULT 0,
  `created_datetime` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`file_id`),
  KEY `work_id` (`assignment_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table classroom.assignment_files: ~9 rows (approximately)
INSERT INTO `assignment_files` (`file_id`, `assignment_id`, `file_name`, `file_path`, `file_size`, `deleted_flg`, `created_datetime`) VALUES
	(11, 16, 'asus.jpg', 'C:\\Users\\pond1\\OneDrive\\เดสก์ท็อป\\PJ-Hub\\backend\\uploads\\assignments\\1790683003534-512489726.jpg', 1768942, 0, '2026-09-29 11:56:43'),
	(12, 16, '519418675_2160688764394094_4682523181030450484_n.jpg', 'C:\\Users\\pond1\\OneDrive\\เดสก์ท็อป\\PJ-Hub\\backend\\uploads\\assignments\\1790683003539-276457638.jpg', 37546, 0, '2026-09-29 11:56:43'),
	(13, 17, 'Screenshot 2025-04-25 183433.png', 'C:\\Users\\pond1\\OneDrive\\เดสก์ท็อป\\PJ-Hub\\backend\\uploads\\assignments\\1790683079839-274814190.png', 2287883, 0, '2026-09-29 11:57:59'),
	(14, 18, '519418675_2160688764394094_4682523181030450484_n.jpg', 'C:\\Users\\pond1\\OneDrive\\เดสก์ท็อป\\PJ-Hub\\backend\\uploads\\assignments\\1790683110755-201782727.jpg', 37546, 0, '2026-09-29 11:58:30'),
	(15, 25, '519418675_2160688764394094_4682523181030450484_n.jpg', 'C:\\Users\\pond1\\OneDrive\\เดสก์ท็อป\\PJ-Hub\\backend\\uploads\\assignments\\1790685014314-948818631.jpg', 37546, 0, '2026-09-29 12:30:14'),
	(16, 28, '519418675_2160688764394094_4682523181030450484_n.jpg', 'C:\\Users\\pond1\\OneDrive\\เดสก์ท็อป\\PJ-Hub\\backend\\uploads\\assignments\\1790685144815-82508640.jpg', 37546, 0, '2026-09-29 12:32:24'),
	(17, 29, '519418675_2160688764394094_4682523181030450484_n.jpg', 'C:\\Users\\pond1\\OneDrive\\เดสก์ท็อป\\PJ-Hub\\backend\\uploads\\assignments\\1790685166094-860849051.jpg', 37546, 0, '2026-09-29 12:32:46'),
	(18, 26, 'AI Prompt V.1.txt', 'C:\\Users\\pond1\\OneDrive\\เดสก์ท็อป\\PJ-Hub\\backend\\uploads\\assignments\\1791618433187-390405041.txt', 20606, 0, '2026-10-10 07:47:13'),
	(19, 36, 'AI Prompt V.1.txt', 'C:\\Users\\pond1\\OneDrive\\เดสก์ท็อป\\PJ-Hub\\backend\\uploads\\assignments\\1791689646092-35711701.txt', 20606, 0, '2026-10-11 03:34:06');

-- Dumping structure for table classroom.classes
CREATE TABLE IF NOT EXISTS `classes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `class_id` varchar(20) NOT NULL DEFAULT '0',
  `class_name` varchar(100) NOT NULL DEFAULT '0',
  `class_describe` varchar(500) NOT NULL DEFAULT '0',
  `deleted_flg` int(11) NOT NULL,
  `deleted_by` varchar(10) DEFAULT NULL,
  `created_by` varchar(10) NOT NULL,
  `created_datetime` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`,`class_id`),
  KEY `class_id` (`class_id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='เก็บรายวิชา';

-- Dumping data for table classroom.classes: ~23 rows (approximately)
INSERT INTO `classes` (`id`, `class_id`, `class_name`, `class_describe`, `deleted_flg`, `deleted_by`, `created_by`, `created_datetime`) VALUES
	(1, 'web01', 'webtest', 'testtesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttest', 1, '00001', '00001', '2026-01-21 15:30:08'),
	(2, 'test02', 'test02', 'test02test02test02test02test02test02test02', 1, '00001', '00001', '2026-01-24 15:05:43'),
	(3, 'test03', 'test03', 'test03test03test03test03test03', 1, '00001', '00001', '2026-01-24 15:06:02'),
	(4, 'test04', 'test04', 'test04test04test04test04test04test04', 1, '00001', '00001', '2026-01-24 15:06:10'),
	(5, 'test05', 'test05', 'test05test05test05test05test05', 1, '00001', '00001', '2026-01-24 15:06:23'),
	(6, 'test06', 'test06', 'test06test06test06test06test06', 1, '00001', '00001', '2026-01-24 15:06:30'),
	(7, 'test07', 'test07', 'test07test07test07test07test07test07', 1, '00001', '00001', '2026-01-24 15:06:36'),
	(8, 'test08', 'test08', 'test08test08test08test08test08', 1, '00001', '00001', '2026-01-24 15:06:43'),
	(9, 'test09', 'test09', 'test09test09test09test09test09test09', 1, '00001', '00001', '2026-01-24 15:06:50'),
	(10, 'test10', 'test10', 'test10test10test10test10test10test10', 1, '00001', '00001', '2026-01-24 15:06:55'),
	(11, 'APP06', 'การพัฒนาเว็บแอปพลิเคชัน (Web Application Development)', 'เรียนการสร้างเว็บด้วย HTML, CSS, JavaScript การพัฒนาฝั่งเซิร์ฟเวอร์ การสร้าง API และการเชื่อมต่อกับฐานข้อมูล', 0, NULL, '00001', '2026-01-25 14:45:15'),
	(12, 'DB01', 'ฐานข้อมูล (Database Systems)', 'เรียนการออกแบบฐานข้อมูลเชิงสัมพันธ์ ภาษา SQL การทำนอร์มัลไลเซชัน ทรานแซกชัน และแนวคิดเบื้องต้นของฐานข้อมูล NoSQL', 0, NULL, '00001', '2026-01-25 15:14:17'),
	(13, 'OOP09', 'การเขียนโปรแกรมเชิงวัตถุ (Object-Oriented Programming)', 'เรียนแนวคิดคลาสและออบเจกต์ การสืบทอด การพ้องรูป (polymorphism) การห่อหุ้มข้อมูล และรูปแบบการออกแบบ (design patterns)', 0, NULL, '00001', '2026-02-07 14:00:31'),
	(15, 'SYT06', 'ความมั่นคงปลอดภัยของระบบสารสนเทศ (Information Security)', 'เรียนการเข้ารหัสลับ การพิสูจน์ตัวตน ช่องโหว่และการโจมตีทั่วไป และแนวทางป้องกันระบบ', 0, NULL, '00001', '2026-02-08 07:47:07'),
	(16, 'AI02', 'ปัญญาประดิษฐ์ (Artificial Intelligence)', 'เรียนการค้นหาและการแก้ปัญหา การแทนความรู้ การให้เหตุผล และแนวคิดพื้นฐานของระบบอัจฉริยะ', 0, NULL, '00001', '2026-02-08 07:48:12'),
	(17, 'JAVA001', 'Java Programming', 'Java Programming', 0, NULL, '00001', '2026-02-08 07:48:37'),
	(18, 'ITP09', 'การเขียนโปรแกรมเบื้องต้น (Introduction to Programming)', 'เรียนหลักการเขียนโปรแกรม ได้แก่ ตัวแปร ชนิดข้อมูล เงื่อนไข การวนซ้ำ ฟังก์ชัน และการแก้ปัญหาด้วยขั้นตอนวิธี โดยมักใช้ภาษา Python, Java หรือ C', 0, NULL, '00001', '2026-02-08 07:49:12'),
	(19, 'CGI332', 'คอมพิวเตอร์กราฟิกและการมองเห็นของคอมพิวเตอร์ (Computer Graphics / Computer Vision)', 'เรียนการสร้างและประมวลผลภาพดิจิทัล และการให้คอมพิวเตอร์ตีความข้อมูลจากภาพ', 0, NULL, '00001', '2026-02-08 07:50:57'),
	(20, 'COM059', 'วิศวกรรมซอฟต์แวร์ (Software Engineering)', 'เรียนวงจรการพัฒนาซอฟต์แวร์ การวิเคราะห์และออกแบบระบบ การทดสอบ การทำงานเป็นทีม เช่น Agile/Scrum และการใช้ Git', 0, NULL, '00001', '2026-02-08 07:51:19'),
	(21, 'CPTA088', 'สถาปัตยกรรมคอมพิวเตอร์ (Computer Architecture)', 'เรียนการทำงานภายในของคอมพิวเตอร์ ได้แก่ ซีพียู หน่วยความจำ ระบบบัส การประมวลผลแบบไปป์ไลน์ และภาษาแอสเซมบลี', 0, NULL, '00001', '2026-02-08 07:51:40'),
	(24, 'DBSTT05', 'โครงสร้างข้อมูลและอัลกอริทึม (Data Structures and Algorithms)', 'เรียนโครงสร้างข้อมูล เช่น อาร์เรย์ ลิงก์ลิสต์ สแตก คิว ต้นไม้ กราฟ และตารางแฮช รวมถึงอัลกอริทึมการค้นหา การเรียงลำดับ และการวิเคราะห์ความซับซ้อนด้วย Big-O', 0, NULL, '69001', '2026-02-16 13:44:11'),
	(25, 'PRO25', 'การเขียนโปรแกรมเบื้องต้น (Introduction to Programming)', 'เรียนหลักการเขียนโปรแกรม ได้แก่ ตัวแปร ชนิดข้อมูล เงื่อนไข การวนซ้ำ ฟังก์ชัน และการแก้ปัญหาด้วยขั้นตอนวิธี โดยมักใช้ภาษา Python, Java หรือ C', 0, NULL, '00001', '2026-02-20 15:53:48'),
	(26, 'NW05', 'เครือข่ายคอมพิวเตอร์ (Computer Networks)', 'เรียนแบบจำลอง OSI และ TCP/IP โปรโตคอลต่าง ๆ เช่น HTTP, DNS, TCP/UDP การกำหนดเส้นทาง (routing) และหลักการของอินเทอร์เน็ต', 0, NULL, '69001', '2026-09-29 00:28:57');

-- Dumping structure for table classroom.class_assignments
CREATE TABLE IF NOT EXISTS `class_assignments` (
  `assignment_id` int(11) NOT NULL AUTO_INCREMENT,
  `class_id` varchar(10) NOT NULL,
  `assignment_type` varchar(20) NOT NULL,
  `assignment_name` varchar(60) DEFAULT NULL,
  `assignment_detail` varchar(500) DEFAULT NULL,
  `assignment_link` varchar(300) DEFAULT NULL,
  `view_cnt` int(11) DEFAULT 0,
  `deleted_flg` int(11) DEFAULT NULL,
  `created_by` varchar(10) DEFAULT NULL,
  `deleted_by` varchar(10) DEFAULT NULL,
  `created_datetime` timestamp NULL DEFAULT current_timestamp(),
  `updated_datetime` datetime DEFAULT NULL,
  PRIMARY KEY (`assignment_id`) USING BTREE,
  KEY `class_id` (`class_id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table classroom.class_assignments: ~21 rows (approximately)
INSERT INTO `class_assignments` (`assignment_id`, `class_id`, `assignment_type`, `assignment_name`, `assignment_detail`, `assignment_link`, `view_cnt`, `deleted_flg`, `created_by`, `deleted_by`, `created_datetime`, `updated_datetime`) VALUES
	(16, 'PRO25', 'Other', 'เครื่องคิดเลขบนคอนโซล', 'รับตัวเลขและตัวดำเนินการ แล้วแสดงผลลัพธ์ ฝึกเงื่อนไขและฟังก์ชัน', 'https://github.com/Teeraphat120945', 5, 0, '69018', NULL, '2026-09-29 11:56:43', NULL),
	(17, 'PRO25', 'Document', 'เกมทายตัวเลข:', 'สุ่มเลขให้ผู้เล่นทาย พร้อมบอกใบ้มากไป/น้อยไป ฝึกการวนซ้ำ', 'https://www.canva.com/design/DAHXfAvFhig/1rTRbVVAVoVVTect9D4azA/edit?ui=e30', 15, 0, '69018', NULL, '2026-09-29 11:57:59', '2026-10-09 13:33:28'),
	(18, 'PRO25', 'Other', 'โปรแกรมคำนวณเกรดเฉลี่ย', 'รับคะแนนหลายวิชาแล้วคำนวณเกรดและ GPA', NULL, 2, 0, '69018', NULL, '2026-09-29 11:58:30', NULL),
	(19, 'PRO25', 'Document', 'การหาเส้นทางสั้นที่สุดบนแผนที่', 'ใช้ทฤษฎีกราฟจำลองเส้นทางระหว่างสถานที่ในมหาวิทยาลัย', 'https://drive.google.com/drive/u/1/folders/1Oxt_uE9dPeKjTYgZjfKZ_0rLGSR12o1o', 3, 0, '69018', NULL, '2026-09-29 12:00:57', NULL),
	(20, 'DBSTT05', 'Document', 'ปรียบเทียบอัลกอริทึมการเรียงลำดับเขียน', 'Bubble, Merge และ Quick Sort แล้ววัดเวลาการทำงานกับ', NULL, 9, 0, '69018', NULL, '2026-09-29 12:06:29', NULL),
	(21, 'CPTA088', 'Application', 'ตัวจำลองซีพียูอย่างง่าย', 'เขียนโปรแกรมจำลองการ fetch, decode, execute ของชุดคำสั่งขนาดเล็ก', NULL, 3, 0, '69018', NULL, '2026-09-29 12:08:31', NULL),
	(22, 'CPTA088', 'Web', 'โปรแกรมแอสเซมบลีคำนวณแฟกทอเรียล', 'ฝึกใช้รีจิสเตอร์และคำสั่งกระโดด', 'https://www.youtube.com/', 3, 0, '69018', NULL, '2026-09-29 12:09:06', NULL),
	(23, 'NW05', 'Web', 'test การเเจ้งเตือน', 'none', NULL, 0, 0, '69018', NULL, '2026-09-29 12:25:22', NULL),
	(24, 'NW05', 'Web', 'โปรแกรมแชตแบบไคลเอนต์-เซิร์ฟเวอร์', 'ใช้ socket ให้ผู้ใช้หลายคนสนทนากันได้', NULL, 0, 0, '69018', NULL, '2026-09-29 12:29:52', NULL),
	(25, 'NW05', 'Web', 'วิเคราะห์แพ็กเก็ตด้วย Wireshark', 'จับและอธิบายลำดับการสื่อสารของ HTTP และ TCP handshake', NULL, 3, 0, '69018', NULL, '2026-09-29 12:30:14', NULL),
	(26, 'COM059', 'Web Application', 'ระบบจองห้องประชุมออนไลน์', 'ทำงานเป็นทีมตามแนว Scrum พร้อมเอกสารความต้องการ แผนภาพ UML และแผนทดสอบ', 'https://www.youtube.com/', 44, 0, '69018', NULL, '2026-09-29 12:30:58', '2026-10-10 14:47:13'),
	(27, 'COM059', 'IOT', 'ปรับปรุงโค้ดเดิม (Refactoring)', 'นำโปรเจกต์โอเพนซอร์สขนาดเล็กมาปรับโครงสร้างและเขียนเทสต์เพิ่ม', NULL, 0, 0, '69018', NULL, '2026-09-29 12:31:44', NULL),
	(28, 'DB01', 'IOT', 'ระบบจัดการร้านหนังสือ', 'ออกแบบ ER Diagram ทำนอร์มัลไลเซชัน และเขียน SQL สำหรับรายงานยอดขาย', NULL, 2, 0, '69018', NULL, '2026-09-29 12:32:24', NULL),
	(29, 'DB01', 'Web Application', 'ระบบทะเบียนนักศึกษา', 'จัดการข้อมูลรายวิชา การลงทะเบียน และเกรด พร้อมใช้ทรานแซกชัน', 'https://www.youtube.com/', 1, 0, '69018', NULL, '2026-09-29 12:32:46', NULL),
	(30, 'OOP09', 'Web', 'ระบบจัดการห้องสมุด', 'ออกแบบคลาสหนังสือ สมาชิก และการยืม-คืน โดยใช้การสืบทอดและ polymorphism', NULL, 1, 0, '69018', NULL, '2026-09-29 12:33:30', NULL),
	(31, 'OOP09', 'IOT', 'เกมต่อสู้ตัวละครอย่างง่าย', 'ใช้ design pattern เช่น Strategy สำหรับพฤติกรรมการโจมตี', NULL, 1, 0, '69018', NULL, '2026-09-29 12:33:46', NULL),
	(32, 'APP06', 'Document', 'เว็บบล็อกส่วนตัว', 'มีระบบสมาชิก เขียนและแก้ไขบทความ และคอมเมนต์', NULL, 1, 0, '69018', NULL, '2026-09-29 12:34:28', NULL),
	(33, 'APP06', 'Web', 'เว็บร้านค้าออนไลน์', 'มีตะกร้าสินค้า ระบบสั่งซื้อ และ REST API', NULL, 1, 0, '69018', NULL, '2026-09-29 12:34:41', NULL),
	(34, 'AI02', 'IOT', 'โปรแกรมเล่นเกม Tic-Tac-Toe ด้วย Minimax', 'ห้ AI เลือกการเดินที่ดีที่สุด', NULL, 8, 0, '69018', NULL, '2026-09-29 12:35:41', NULL),
	(35, 'AI02', 'Other', 'หาทางออกเขาวงกต', 'เปรียบเทียบ BFS, DFS และ A*', NULL, 7, 0, '69018', NULL, '2026-09-29 12:35:54', NULL),
	(36, 'NW05', 'Web', 'test 0099', 'none', 'https://githubx.com/Teeraphat120945/PJ-Hub', 5, 0, '00001', NULL, '2026-10-11 03:34:06', '2026-10-11 10:37:54');

-- Dumping structure for table classroom.class_users
CREATE TABLE IF NOT EXISTS `class_users` (
  `class_id` varchar(10) NOT NULL DEFAULT '',
  `user_id` varchar(10) NOT NULL DEFAULT '',
  `view_flg` int(11) DEFAULT NULL,
  `deleted_flg` int(11) DEFAULT NULL,
  `deleted_by` varchar(10) DEFAULT NULL,
  `created_datetime` datetime DEFAULT current_timestamp(),
  `updated_datetime` datetime DEFAULT NULL,
  PRIMARY KEY (`class_id`,`user_id`),
  KEY `class_id` (`class_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='permission';

-- Dumping data for table classroom.class_users: ~69 rows (approximately)
INSERT INTO `class_users` (`class_id`, `user_id`, `view_flg`, `deleted_flg`, `deleted_by`, `created_datetime`, `updated_datetime`) VALUES
	('AI02', '00001', 0, 0, NULL, '2026-09-29 18:51:37', NULL),
	('AI02', '69018', 0, 0, NULL, '2026-09-29 18:51:37', NULL),
	('APP06', '00001', 0, 0, NULL, '2026-09-29 18:51:37', NULL),
	('APP06', '69018', 0, 0, NULL, '2026-09-29 18:51:37', NULL),
	('BAS015', '00001', 0, 0, NULL, '2026-02-08 14:51:19', NULL),
	('BAS015', '69018', 0, 0, NULL, '2026-09-11 16:02:29', NULL),
	('CGI332', '00001', 0, 0, NULL, '2026-09-29 18:51:37', NULL),
	('CGI332', '69018', 0, 0, NULL, '2026-09-29 18:51:37', NULL),
	('COM059', '00001', 0, 0, NULL, '2026-09-29 18:51:37', NULL),
	('COM059', '69018', 0, 0, NULL, '2026-09-29 18:51:37', NULL),
	('CPTA088', '00001', 0, 0, NULL, '2026-09-29 18:51:37', NULL),
	('CPTA088', '69018', 0, 0, NULL, '2026-09-29 18:51:37', NULL),
	('DB01', '00001', 0, 0, NULL, '2026-09-29 18:51:37', NULL),
	('DB01', '69018', 0, 0, NULL, '2026-09-29 18:51:37', NULL),
	('DBSTT05', '00001', 0, 0, NULL, '2026-09-29 18:51:37', NULL),
	('DBSTT05', '69001', 0, 0, NULL, '2026-10-01 10:43:58', NULL),
	('DBSTT05', '69018', 0, 0, NULL, '2026-09-29 18:51:37', NULL),
	('ENG101', '00001', 0, 0, NULL, '2026-02-08 14:50:57', NULL),
	('ENG101', '69018', 0, 0, NULL, '2026-09-11 16:02:29', NULL),
	('ezwin12', '00001', 0, 0, NULL, '2026-09-29 07:28:57', NULL),
	('ezwin12', '69001', 0, 0, NULL, '2026-09-29 07:28:57', NULL),
	('ezwin12', '69018', 0, 0, NULL, '2026-09-29 07:28:57', NULL),
	('GAME01', '00001', 0, 0, NULL, '2026-02-20 22:53:48', NULL),
	('GAME01', '69003', 0, 0, NULL, '2026-09-26 17:53:51', NULL),
	('GAME01', '69018', 0, 0, NULL, '2026-09-11 16:02:29', NULL),
	('ITP09', '00001', 0, 0, NULL, '2026-09-29 18:51:37', NULL),
	('ITP09', '69018', 0, 0, NULL, '2026-09-29 18:51:37', NULL),
	('JAVA001', '00001', 0, 0, NULL, '2026-02-08 14:48:37', NULL),
	('JAVA001', '69018', 0, 0, NULL, '2026-09-11 16:02:29', NULL),
	('LAB12', '00001', 0, 0, NULL, '2026-01-25 22:14:17', '2026-02-01 23:59:58'),
	('LAB12', '69004', 0, 0, NULL, '2026-02-02 00:02:52', '2026-02-02 00:02:52'),
	('LAB12', '69007', 1, 1, '00001', '2026-02-10 18:25:41', NULL),
	('LAB12', '69018', 0, 0, NULL, '2026-09-11 16:02:29', NULL),
	('NET152', '00001', 0, 0, NULL, '2026-02-08 14:49:12', NULL),
	('NET152', '69018', 0, 0, NULL, '2026-09-11 16:02:29', NULL),
	('NW05', '00001', 0, 0, NULL, '2026-09-29 18:51:37', NULL),
	('NW05', '69001', 0, 0, NULL, '2026-09-29 21:10:50', NULL),
	('NW05', '69003', 0, 0, NULL, '2026-09-29 21:11:16', NULL),
	('NW05', '69018', 0, 0, NULL, '2026-09-29 18:51:37', NULL),
	('OOP09', '00001', 0, 0, NULL, '2026-09-29 18:51:37', NULL),
	('OOP09', '69018', 0, 0, NULL, '2026-09-29 18:51:37', NULL),
	('OOP101', '00001', 0, 0, NULL, '2026-02-07 21:00:31', NULL),
	('OOP101', '69018', 0, 0, NULL, '2026-09-11 16:02:29', NULL),
	('PRO25', '00001', 0, 0, NULL, '2026-09-29 18:51:37', NULL),
	('PRO25', '69018', 0, 0, NULL, '2026-09-29 18:51:37', NULL),
	('STAT13', '00001', 0, 0, NULL, '2026-02-08 14:48:12', NULL),
	('STAT13', '69018', 0, 0, NULL, '2026-09-11 16:02:29', NULL),
	('STAT14', '00001', 0, 0, NULL, '2026-02-08 14:51:40', NULL),
	('STAT14', '69001', 1, 1, NULL, '2026-02-08 15:21:52', NULL),
	('STAT14', '69018', 0, 0, NULL, '2026-09-11 16:02:29', NULL),
	('STEM12', '00001', 0, 0, NULL, '2026-02-08 14:47:07', NULL),
	('STEM12', '69018', 0, 0, NULL, '2026-09-11 16:02:29', NULL),
	('SYT06', '00001', 0, 0, NULL, '2026-09-29 18:51:37', NULL),
	('SYT06', '69018', 0, 0, NULL, '2026-09-29 18:51:37', NULL),
	('TECH0185', '00001', 0, 0, NULL, '2026-02-16 20:44:11', NULL),
	('TECH0185', '69001', 0, 0, NULL, '2026-02-16 20:44:11', NULL),
	('TECH0185', '69003', 1, 1, '00001', '2026-02-20 22:48:52', NULL),
	('TECH0185', '69005', 0, 0, NULL, '2026-02-20 22:49:01', NULL),
	('TECH0185', '69018', 0, 0, NULL, '2026-09-11 16:02:29', NULL),
	('web11', '00001', 0, 0, NULL, '2026-01-25 21:45:15', '2026-02-01 23:59:58'),
	('web11', '69001', 0, 0, NULL, '2026-02-01 23:59:33', '2026-02-01 23:59:58'),
	('web11', '69002', 0, 0, NULL, '2026-02-01 23:59:33', '2026-02-01 23:59:58'),
	('web11', '69004', 0, 0, NULL, '2026-02-01 18:19:03', '2026-02-01 23:59:58'),
	('web11', '69005', 0, 0, NULL, '2026-02-01 23:59:34', '2026-02-01 23:59:58'),
	('web11', '69006', 0, 0, NULL, '2026-02-01 23:59:34', '2026-02-01 23:59:58'),
	('web11', '69007', 0, 0, NULL, '2026-02-01 23:59:34', '2026-02-01 23:59:58'),
	('web11', '69008', 0, 0, NULL, '2026-02-01 23:59:35', '2026-02-01 23:59:58'),
	('web11', '69009', 0, 0, NULL, '2026-02-02 00:15:58', NULL),
	('web11', '69018', 0, 0, NULL, '2026-09-11 16:02:29', NULL);

-- Dumping structure for table classroom.ref_number
CREATE TABLE IF NOT EXISTS `ref_number` (
  `name` varchar(50) NOT NULL DEFAULT '',
  `prefix` varchar(50) DEFAULT NULL,
  `current_value` int(11) DEFAULT 1,
  `pad_length` int(11) DEFAULT 2,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table classroom.ref_number: ~1 rows (approximately)
INSERT INTO `ref_number` (`name`, `prefix`, `current_value`, `pad_length`) VALUES
	('user', '69', 23, 2);

-- Dumping structure for table classroom.ref_role
CREATE TABLE IF NOT EXISTS `ref_role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) NOT NULL DEFAULT 0,
  `role_name` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`,`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table classroom.ref_role: ~4 rows (approximately)
INSERT INTO `ref_role` (`id`, `role_id`, `role_name`) VALUES
	(1, 0, 'ผู้ดูแลระบบ'),
	(2, 1, 'อาจารย์'),
	(3, 2, 'นักเรียน'),
	(4, 3, 'ผู้ใช้ทั่วไป');

-- Dumping structure for table classroom.users
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(10) NOT NULL DEFAULT '0',
  `user_name` varchar(50) NOT NULL,
  `user_password` varchar(255) DEFAULT NULL,
  `google_id` varchar(255) DEFAULT NULL,
  `microsoft_id` varchar(255) DEFAULT NULL,
  `avatar_url` varchar(500) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `role_flg` int(11) DEFAULT NULL,
  `deleted_flg` int(11) NOT NULL,
  `last_login` datetime DEFAULT NULL,
  `created_datetime` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_datetime` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`,`user_id`) USING BTREE,
  UNIQUE KEY `user_name` (`user_name`),
  UNIQUE KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table classroom.users: ~24 rows (approximately)
INSERT INTO `users` (`id`, `user_id`, `user_name`, `user_password`, `google_id`, `microsoft_id`, `avatar_url`, `email`, `role_flg`, `deleted_flg`, `last_login`, `created_datetime`, `updated_datetime`) VALUES
	(1, '00001', 'admin', '$2b$10$clqi0BzvKooB5BtSCDTrseEuJXchlOjSbKS.Ardv80Ns3SVG1Zv8.', NULL, NULL, NULL, '', 0, 0, '2026-10-27 17:06:37', '2026-01-18 14:11:54', NULL),
	(2, '69001', 'teacher', '$2b$10$clqi0BzvKooB5BtSCDTrseEuJXchlOjSbKS.Ardv80Ns3SVG1Zv8.', NULL, NULL, NULL, '', 1, 0, '2026-10-11 10:28:12', '2026-01-18 14:22:06', NULL),
	(3, '69002', 'student01', '$2b$10$clqi0BzvKooB5BtSCDTrseEuJXchlOjSbKS.Ardv80Ns3SVG1Zv8.', NULL, NULL, NULL, '', 2, 0, '2026-10-11 10:26:44', '2026-01-18 14:22:53', NULL),
	(4, '69003', 'other', '$2b$10$clqi0BzvKooB5BtSCDTrseEuJXchlOjSbKS.Ardv80Ns3SVG1Zv8.', NULL, NULL, NULL, '', 3, 0, '2026-10-10 14:44:43', '2026-01-18 14:24:04', NULL),
	(5, '69004', 'student02', '$2b$10$KeRjpR.La3MO0N90gM.K6uo4wwgO7YKDqcWHWhUA4JdH3Z3Z6ElBm', NULL, NULL, NULL, '', 2, 0, '2026-02-10 18:33:58', '2026-01-24 14:17:00', NULL),
	(6, '69005', 'student03', '$2b$10$CteeuAXh9GPdOR0xvoCScuhWPvP6qHZdtlQyIEwL53UYJjMqx3isq', NULL, NULL, NULL, '', 2, 0, NULL, '2026-01-24 14:17:10', NULL),
	(7, '69006', 'student04', '$2b$10$MW2APc1UmAM4fJT8AxBYy.o8cX.4/Js7v270T33NGqrbqumkAGKXC', NULL, NULL, NULL, '', 2, 0, NULL, '2026-01-24 14:18:05', NULL),
	(8, '69007', 'student05', '$2b$10$WPd1Nsa1ihkta2ioA926Lu0D/TE5Qm2hXpSjmlVnFvqUY0ZAQQDyq', NULL, NULL, NULL, '', 2, 0, NULL, '2026-01-24 14:18:59', NULL),
	(9, '69008', 'student06', '$2b$10$3ItPKQgTI0l7RhB9LkHOSOinRxzey3BYiK4T64SHs1qs06kDcPgo2', NULL, NULL, NULL, '', 2, 0, NULL, '2026-01-24 14:19:11', NULL),
	(10, '69009', 'student07', '$2b$10$izwD5ZrfbMrnbUYid0NjVuW81UjsI5IOdGt1O2xwvmP2U.7XClZym', NULL, NULL, NULL, '', 2, 0, NULL, '2026-01-24 14:19:21', NULL),
	(11, '69010', 'student08', '$2b$10$2I.GkPrcunrJBqoTbIuFzu0B2f2YiQ/7NyL/zgKmxP82zDMCdILDS', NULL, NULL, NULL, '', 2, 0, NULL, '2026-01-24 14:19:42', NULL),
	(12, '69011', 'student09', '$2b$10$nI3GTBNMgy3Dvg11udUMne5hV0eNmSD75gnLVVGCM8UyBV8/kmYN.', NULL, NULL, NULL, '', 2, 0, NULL, '2026-01-24 14:19:55', NULL),
	(13, '69012', 'student10', '$2b$10$mk30Z22qmTUicG62MdhHQOnIkICEio8R0/6e1ChxT9byW2qXTFFfy', NULL, NULL, NULL, '', 2, 0, NULL, '2026-01-24 14:20:08', NULL),
	(14, '69013', 'student11', '$2b$10$clqi0BzvKooB5BtSCDTrseEuJXchlOjSbKS.Ardv80Ns3SVG1Zv8.', NULL, NULL, NULL, '', 3, 0, NULL, '2026-02-01 11:31:10', NULL),
	(15, '69014', 'teacher01', '$2b$10$3v9Qnn2m7JydglkF7xlyi.5Pn.pGPS8FD8ovfEg9NJcxEHMUGi5gu', NULL, NULL, NULL, '', 1, 0, NULL, '2026-02-10 11:11:51', NULL),
	(16, '69015', 'มะขิ่น', NULL, NULL, NULL, NULL, 'kornkitsana@gmail.com', 3, 0, '2026-08-23 12:35:14', '2026-08-23 05:35:14', NULL),
	(17, '69016', 'kornkitsana phanthom', NULL, NULL, NULL, NULL, 'inwfrog123@gmail.com', 3, 0, '2026-08-23 13:19:27', '2026-08-23 06:19:27', NULL),
	(18, '69017', 'fasffds afafssafas', NULL, NULL, NULL, NULL, 'fafafssafas@gmail.com', 3, 0, '2026-08-23 13:22:06', '2026-08-23 06:22:06', NULL),
	(19, '69018', 'THIRAPAT WANGKEEREE', NULL, NULL, NULL, NULL, '64021182@up.ac.th', 0, 0, '2026-10-11 11:09:16', '2026-09-11 02:15:24', NULL),
	(20, '69019', 'Pond Disciple', NULL, NULL, NULL, NULL, 'eaypuy5@gmail.com', 3, 0, '2026-10-10 06:51:11', '2026-09-18 08:48:39', NULL),
	(21, '69020', 'tester999', '$2b$10$EJz1okJ3st/Eb9opnQXC1.qvrDEIW/hQQlvxEEn6bLEnqnegsMU8y', NULL, NULL, NULL, 'stupid@gmail.com', 3, 0, '2026-09-19 17:18:16', '2026-09-19 10:17:28', NULL),
	(22, '69021', 'OP ID', NULL, NULL, NULL, NULL, 'pond1670201287377@gmail.com', 3, 0, '2026-10-11 11:08:57', '2026-10-10 00:43:43', NULL),
	(23, '69022', 'wattanapong.su', '$2b$10$QDkxD3XOoi8F3hJja9fjEOwi8DSwEzpQyC4MLYw1h5J7zmPt9OZJ2', NULL, NULL, NULL, 'wattanapong.su@outlook.com', 3, 0, '2026-10-11 11:15:30', '2026-10-11 03:52:31', NULL),
	(24, '69023', 'wattanapong suttapak', NULL, NULL, NULL, NULL, 'wattanapong.su@up.ac.th', 3, 0, '2026-10-11 11:12:29', '2026-10-11 04:12:29', NULL);

-- Dumping structure for table classroom.user_auth_providers
CREATE TABLE IF NOT EXISTS `user_auth_providers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(10) NOT NULL,
  `provider` varchar(20) NOT NULL,
  `provider_user_id` varchar(255) NOT NULL,
  `provider_email` varchar(255) DEFAULT NULL,
  `created_datetime` timestamp NULL DEFAULT current_timestamp(),
  `updated_datetime` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_provider_user` (`provider`,`provider_user_id`),
  KEY `fk_auth_provider_user` (`user_id`),
  CONSTRAINT `fk_auth_provider_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table classroom.user_auth_providers: ~8 rows (approximately)
INSERT INTO `user_auth_providers` (`id`, `user_id`, `provider`, `provider_user_id`, `provider_email`, `created_datetime`, `updated_datetime`) VALUES
	(1, '69015', 'google', '106108961811069040901', 'kornkitsana@gmail.com', '2026-08-23 05:35:14', '2026-08-23 05:35:14'),
	(2, '69016', 'microsoft', 'e668895eec4e90f9', 'inwfrog123@gmail.com', '2026-08-23 06:19:27', '2026-08-23 06:19:27'),
	(3, '69017', 'google', '117933660653859381463', 'fafafssafas@gmail.com', '2026-08-23 06:22:06', '2026-08-23 06:22:06'),
	(4, '69018', 'google', '102212229442084957809', '64021182@up.ac.th', '2026-09-11 02:15:24', '2026-09-19 07:51:45'),
	(6, '69019', 'google', '114721844007832913500', 'eaypuy5@gmail.com', '2026-09-18 08:48:39', '2026-09-18 08:48:39'),
	(8, '69018', 'microsoft', '83482eaf-5dde-42d3-8d51-734c54755919', '64021182@up.ac.th', '2026-09-21 07:55:19', '2026-09-21 07:55:19'),
	(9, '69021', 'google', '105472917812680706608', 'pond1670201287377@gmail.com', '2026-10-10 00:43:43', '2026-10-10 00:43:43'),
	(10, '69023', 'microsoft', '2824ab47-4029-4dbe-b846-e3c9268c5514', 'wattanapong.su@up.ac.th', '2026-10-11 04:12:29', '2026-10-11 04:12:29');

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
